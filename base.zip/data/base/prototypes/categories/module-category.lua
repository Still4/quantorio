data:extend(
{
  {
    type = "module-category",
    name = "productivity"
  },
  {
    type = "module-category",
    name = "speed"
  },
  {
    type = "module-category",
    name = "effectivity"
  }
}
)
