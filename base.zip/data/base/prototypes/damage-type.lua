data:extend(
{
  {
    type = "damage-type",
    name = "physical"
  },
  {
    type = "damage-type",
    name = "impact"
  },
  {
    type = "damage-type",
    name = "poison"
  },
  {
    type = "damage-type",
    name = "explosion"
  },
  {
    type = "damage-type",
    name = "fire"
  },
  {
    type = "damage-type",
    name = "laser"
  },
  {
    type = "damage-type",
    name = "acid"
  },
  {
    type = "damage-type",
    name = "electric"
  }
}
)
