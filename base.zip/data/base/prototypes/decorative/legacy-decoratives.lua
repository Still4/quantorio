data:extend(
{
  {
    type = "decorative",
    name = "brown-asterisk"
  },
  {
    type = "decorative",
    name = "green-asterisk"
  },
  {
    type = "decorative",
    name = "red-asterisk"
  },
  {
    type = "decorative",
    name = "green-pita"
  },
  {
    type = "decorative",
    name = "green-pita-mini"
  },
  {
    type = "decorative",
    name = "brown-cane-cluster"
  },
  {
    type = "decorative",
    name = "brown-cane-single"
  },
  {
    type = "decorative",
    name = "green-coral-mini"
  },
  {
    type = "decorative",
    name = "brown-coral-mini"
  },
  {
    type = "decorative",
    name = "orange-coral-mini"
  },
  {
    type = "decorative",
    name = "brown-fluff"
  },
  {
    type = "decorative",
    name = "brown-fluff-dry"
  },
  {
    type = "decorative",
    name = "garballo"
  },
  {
    type = "decorative",
    name = "garballo-mini-dry"
  },
  {
    type = "decorative",
    name = "green-bush-mini"
  },
  {
    type = "decorative",
    name = "green-hairy-grass"
  },
  {
    type = "decorative",
    name = "green-carpet-grass"
  },
  {
    type = "decorative",
    name = "green-small-grass"
  },
  {
    type = "decorative",
    name = "root-A"
  },
  {
    type = "decorative",
    name = "root-B"
  },
  {
    type = "decorative",
    name = "brown-carpet-grass"
  },
  {
    type = "decorative",
    name = "brown-hairy-grass"
  },
  {
  type = "decorative",
  name = "big-ship-wreck-grass"
  },
  {
  type = "decorative",
  name = "small-ship-wreck-grass"
  }
})
