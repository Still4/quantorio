data:extend(
{
  {
    type = "noise-layer",
    name = "grass-1"
  },
  {
    type = "noise-layer",
    name = "grass-2"
  },
  {
    type = "noise-layer",
    name = "grass-3"
  },
  {
    type = "noise-layer",
    name = "grass-4"
  },
  {
    type = "noise-layer",
    name = "red-desert-0"
  },
  {
    type = "noise-layer",
    name = "red-desert-1"
  },
  {
    type = "noise-layer",
    name = "red-desert-2"
  },
  {
    type = "noise-layer",
    name = "red-desert-3"
  },
  {
    type = "noise-layer",
    name = "dirt-1"
  },
  {
    type = "noise-layer",
    name = "dirt-2"
  },
  {
    type = "noise-layer",
    name = "dirt-3"
  },
  {
    type = "noise-layer",
    name = "dirt-4"
  },
  {
    type = "noise-layer",
    name = "dirt-5"
  },
  {
    type = "noise-layer",
    name = "dirt-6"
  },
  {
    type = "noise-layer",
    name = "dirt-7"
  },
  {
    type = "noise-layer",
    name = "sand-1"
  },
  {
    type = "noise-layer",
    name = "sand-2"
  },
  {
    type = "noise-layer",
    name = "sand-3"
  },
  {
    type = "noise-layer",
    name = "dry-dirt"
  },
}
)
